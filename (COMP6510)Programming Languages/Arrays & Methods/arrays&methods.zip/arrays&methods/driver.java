import java.util.*;
import packages.myUtilities;

public class driver{

  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);

    myUtilities obj = new myUtilities();
    while(true){
    obj.menu();
    int choice = sc.nextInt();

      switch(choice){
        case 1:{
          obj.Question1();
          break;
        }
        case 2:{
          obj.shiftROT();
          break;
        }
        case 3:{
          obj.SymMatrix();
          break;

        }
        case 4:{
          obj.MagicBox();
          break;
        }
        case 5:{
          System.exit(0);
        }
        default:{
          System.out.println("Invalid Option");
        }
      }

  }
}
}
