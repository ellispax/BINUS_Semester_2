package packages;
import java.util.*;
import java.io.*;

public class myUtilities{
  Scanner sc = new Scanner(System.in);

  public static void menu(){
    System.out.println("-- Choose Question You want to view Solution --");
    System.out.println(" 1 | Question 1 ");
    System.out.println(" 2 | Question 2 ");
    System.out.println(" 3 | Question 3 ");
    System.out.println(" 4 | Question 4 ");
    System.out.println(" 5 | Exit ")
    System.out.println();
    System.out.println(" >> ");
  }

// getting the largest value of the array
  public static int getMax(int[] Arry){
       int max = Arry[0];
       for(int i=1;i < Arry.length;i++){
           if(Arry[i] > max){
               max = Arry[i];
           }
       }
       return max;
   }
   // getting index of an array element
   public static int getindex(int[] Arry){
        int max = Arry[0];
        int index = 0;
        for(int i=1;i < Arry.length;i++){
            if(Arry[i] > max){
                max = Arry[i];
                index = i;
            }
        }
        return index;
    }

    // function to delete an element from an array
    public static int[] deleteElement(int[] arr, int index){
      if (arr == null || index <0 || index >= arr.length){
        return arr;
      }
      int arry1[] = new int[arr.length-1];
      for (int i = 0, k = 0; i <arr.length; i++){
        if(i == index){
          continue;
        }
        arry1[k++] = arr[i];
      }
      return arry1;
    }
// question 1
  public void Question1(){
    int size;
    System.out.println("Enter Size of the Array: ");
    size = sc.nextInt();
    int arry[] = new int[size];
    //inputing elements into the array
    for(int i = 0; i< arry.length;i++){
            System.out.print(": ");
            arry[i] = sc.nextInt();
        }
    System.out.println();
    System.out.println("Input Array is : "+Arrays.toString(arry));
    System.out.println();

    //finding the maximum value in the Array
    int Max = getMax(arry);
    int index = getindex(arry);

      //making new array to place all elements except the largets Value
    int NewArry[] = new int[size - 1];
    NewArry = deleteElement(arry, index);
    int newLarge = getMax(NewArry);
    int diff = Max - newLarge;  // difference of the largest value from the first array and the new large value

    arry[index] = newLarge; // replacing the largest value with the new value from the new array


    int[] result = new int[arry.length+1];
    for(int i = 0; i < index+1; i++)
        result[i] = arry[i];
    result[index+1] = diff;
    for(int i = index+2; i < arry.length+1; i++)
        result[i] = arry[i - 1];    //inserting the new  values:- added will give the largesy value from the first array

    System.out.println();
    System.out.println("The new arry is: "+Arrays.toString(result));

  }


    public void MagicBox(){
      System.out.println("Enter Magic Square size; ");
      int n = sc.nextInt();
       if (n % 2 == 0) throw new RuntimeException("Size must be odd");

       int[][] magic = new int[n][n]; // array is a 2D 

       int row = n-1;
       int col = n/2;
       magic[row][col] = 1;

       for (int i = 2; i <= n*n; i++) {
           if (magic[(row + 1) % n][(col + 1) % n] == 0) {
               row = (row + 1) % n;
               col = (col + 1) % n;
           }
           else {
               row = (row - 1 + n) % n;
               // don't change col
           }
           magic[row][col] = i;
       }

       // print results
       for (int i = 0; i < n; i++) {
           for (int j = 0; j < n; j++) {
               if (magic[i][j] < 10)  System.out.print(" ");  // for alignment
               if (magic[i][j] < 100) System.out.print(" ");  // for alignment
               System.out.print(magic[i][j] + " ");
           }
           System.out.println();
       }



  }

  public  void SymMatrix(){
    int row = 3;
    int col = 3;
    int [][] mat = new int[row][col]; //origonal 3x3 matrix
    int transpose[][] = new int[row][col];  //this will be the transpose

    System.out.println("Enter Elements Of the Matrix: ");

    System.out.print("Please enter numbers to fill up a 3x3 matrix: ");
        for (int i = 0; i < mat.length; i++) {
            for (int x = 0; x < mat.length; x++) {
                mat[i][x] = sc.nextInt();
            }
          }


      int row1, col1, row2, col2;
      boolean flag = true;
      //getting number of columns and rows in the origonal matrix
          row1 = mat.length;
          col1 = mat[0].length;

    //Calculates number of rows and columns present in second matrix
        row2 = transpose.length;
        col2 = transpose[0].length;

  //Checks if dimensions of both the matrices are equal
  if(row1 != row2 || col1 != col2){
         System.out.println("Matrices are not equal");
     }
     else {
         for(int i = 0; i < row1; i++){
             for(int j = 0; j < col1; j++){
               if(mat[i][j] != transpose[i][j]){
                   flag = false;
                   break;
               }
             }
         }


        if(flag){
          System.out.println("Matrices are equal");
        }

        else{
          System.out.println("Matrices are not equal");
        }

    }
  }




  public void shiftROT(){
    int size;
    System.out.println("Enter Size of the Array: ");
    size = sc.nextInt();
    int arry[] = new int[size];
    for(int i = 0; i< arry.length;i++){
            System.out.print(": ");
            arry[i] = sc.nextInt();
        }
    int ROT;
    System.out.println("Enter ROT: ");
    ROT = sc.nextInt();
    int length = arry.length;

    for (int i = 0; i < ROT; i++) {
        int temp = arry[length - 1];
        for (int j = length - 1; j > 0; j--) {
            arry[j] = arry[j - 1];
           }
        arry[0] = temp;
     }
     System.out.println("The new Array is: "+Arrays.toString(arry));
  }




}
