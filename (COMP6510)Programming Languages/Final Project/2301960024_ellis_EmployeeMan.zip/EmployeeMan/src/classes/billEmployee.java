package classes;

import static dbconn.DBconnection.connecto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author Computer
 */
public class billEmployee 
{
    private
            int billID;
            int employeeID;
            String month;
            String year;
            double totall;
            double totded;
            double gross;
            double net;
            int accountNo;
    
    public billEmployee(){}

    public billEmployee(int billID, int employeeID, String month, String year, double totall, double totded, double gross, double net, int accountNo) {
        this.billID = billID;
        this.employeeID = employeeID;
        this.month = month;
        this.year = year;
        this.totall = totall;
        this.totded = totded;
        this.gross = gross;
        this.net = net;
        this.accountNo = accountNo;
    }
    
    public billEmployee(int billID, String month, String year, double totall, double totded, double gross, double net) {
        this.billID = billID;
        this.month = month;
        this.year = year;
        this.totall = totall;
        this.totded = totded;
        this.gross = gross;
        this.net = net;
        
    }

    public static boolean saveEmployeeBill(billEmployee employeeBill) {

        try {
            String sql = "INSERT INTO tblbills(employeeId,month,yr,totAll,totDed,gross,net,account) VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            //pstmt.setInt(1, new Random().nextInt(10000));
            pstmt.setInt(1, employeeBill.getEmployeeID());
            pstmt.setString(2, employeeBill.getMonth());
            pstmt.setString(3, employeeBill.getYear());
            pstmt.setDouble(4, employeeBill.getTotall());
            pstmt.setDouble(5, employeeBill.getTotded());
            pstmt.setDouble(6, employeeBill.getGross());
            pstmt.setDouble(7,employeeBill.getNet());
            pstmt.setInt(8, employeeBill.getAccountNo());
            
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public static List<billEmployee> getAllBills()  {

        try {
            String sql = "SELECT * FROM  tblbills";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<billEmployee> bill = new ArrayList<billEmployee>();
             
            while (resultSet.next()) {
                Integer id = resultSet.getInt("billID");
                String month = resultSet.getString("month");
                String yr = resultSet.getString("yr");
                Double totAll = resultSet.getDouble("totAll");
                Double totded = resultSet.getDouble("totDed");
                Double gross = resultSet.getDouble("gross");
                Double net = resultSet.getDouble("net");
                
                
                
                billEmployee bills = new billEmployee(id, month, yr, totAll, totded,gross,net);
                bill.add(bills);
            }
            return bill;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static List<billEmployee> getBillByEmployeeid(String query) {

        try {
            String sql = "SELECT * FROM tblbills WHERE employeeId='" + query + "'";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<billEmployee> bill = new ArrayList<billEmployee>();
            
            while (resultSet.next()) {
                Integer id = resultSet.getInt("billID");
                String month = resultSet.getString("month");
                String yr = resultSet.getString("yr");
                Double totAll = resultSet.getDouble("totAll");
                Double totded = resultSet.getDouble("totDed");
                Double gross = resultSet.getDouble("gross");
                Double net = resultSet.getDouble("net");
                           
                billEmployee bills = new billEmployee(id, month, yr, totAll, totded,gross,net);
                bill.add(bills);
            }
            return bill;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public int getBillID() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID = billID;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public double getTotall() {
        return totall;
    }

    public void setTotall(double totall) {
        this.totall = totall;
    }

    public double getTotded() {
        return totded;
    }

    public void setTotded(double totded) {
        this.totded = totded;
    }

    public double getGross() {
        return gross;
    }

    public void setGross(double gross) {
        this.gross = gross;
    }

    public double getNet() {
        return net;
    }

    public void setNet(double net) {
        this.net = net;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    @Override
    public String toString() {
        return "billEmployee{" + "billID=" + billID + ", employeeID=" + employeeID + ", month=" + month + ", year=" + year + ", totall=" + totall + ", totded=" + totded + ", gross=" + gross + ", net=" + net + ", accountNo=" + accountNo + '}';
    }
    
    
    
}
