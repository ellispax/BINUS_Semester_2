/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;
import java.util.*;
import static dbconn.DBconnection.connecto;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import javax.activity.InvalidActivityException;
import javax.swing.JOptionPane;

/**
 *
 * @author Computer
 */
public class employees {
    
    private
            String ID;
            String name;
            String surname;
            String nationalID;
            String gender;
            String dob;
            String address;
            String email;
            String mobile;
            String department;
            String grade;
            int salary;
            int accountNo;
            String username;
            String password;
            
            
    public employees(){}

    public employees(String ID, String name, String surname, String nationalID, String gender, String dob,String mobile, String email, String address, String department, String grade, int salary, int accountNo) {
        this.ID = ID;
        this.name = name;
        this.surname = surname;
        this.nationalID = nationalID;
        this.gender = gender;
        this.dob = dob;
        this.address = address;
        this.email = email;
        this.mobile = mobile;
        this.department = department;
        this.grade = grade;
        this.salary = salary;
        this.accountNo = accountNo;
        //this.username = username;
        //this.password = password;
       
    }
    
    public employees(String name, String surname, String nationalID, String gender, String dob,String mobile, String email, String address, String department, String grade, int salary, int accountNo) {
        //this.ID = ID;
        this.name = name;
        this.surname = surname;
        this.nationalID = nationalID;
        this.gender = gender;
        this.dob = dob;
        this.address = address;
        this.email = email;
        this.mobile = mobile;
        this.department = department;
        this.grade = grade;
        this.salary = salary;
        this.accountNo = accountNo;
        //this.username = username;
        //this.password = password;
       
    }
    
    
    public static boolean save(saveEmployee SaveEmployee){
        if(confirmpass(SaveEmployee)){
            
            employees Employee = new employees(SaveEmployee.getName(),SaveEmployee.getSurname(),SaveEmployee.getNationalID(),SaveEmployee.getGender(),SaveEmployee.getDob(),SaveEmployee.getMobile(),SaveEmployee.getEmail(),SaveEmployee.getAddress(),SaveEmployee.getDepartment(),SaveEmployee.getGrade(),SaveEmployee.getSalary(),SaveEmployee.getAccountNo());
            return saveEmployee(Employee);
        }
        return false;
    }
    
    public static boolean saveEmployee(employees employeeAccount) {

        try {
            String sql = "INSERT INTO tblemployees(name,surname,nationalID,gender,dob,phoneNumber,email,homeAddress,department,grade,salary,accountNo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            //pstmt.setInt(1, new Random().nextInt(10000));
            pstmt.setString(1, employeeAccount.getName());
            pstmt.setString(2, employeeAccount.getSurname());
            pstmt.setString(3, employeeAccount.getNationalID());
            pstmt.setString(4, employeeAccount.getGender());
            pstmt.setString(5, employeeAccount.getDob());
            pstmt.setString(6, employeeAccount.getMobile());
            pstmt.setString(7,employeeAccount.getEmail());
            pstmt.setString(8, employeeAccount.getAddress());
            pstmt.setString(9, employeeAccount.getDepartment());
            pstmt.setString(10, employeeAccount.getGrade());
            pstmt.setInt(11, employeeAccount.getSalary());
            pstmt.setInt(12, employeeAccount.getAccountNo());
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    
    public static List<employees> getEmployeeByID(String query) {

        try {
            
            String sql = "SELECT * FROM tblemployees WHERE employeeId='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<employees> employeeList = new ArrayList<employees>();
            while (resultSet.next()) {
                String ID = resultSet.getString("employeeID");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String nationalID = resultSet.getString("nationalID");
                String gender = resultSet.getString("gender");
                String dob = resultSet.getString("dob");
                String mobile = resultSet.getString("phoneNumber");
                String email = resultSet.getString("email");
                String address = resultSet.getString("homeAddress");
                String dept = resultSet.getString("department");
                String grade = resultSet.getString("grade");
                int salary = resultSet.getInt("salary");
                int accountNo = resultSet.getInt("accountNo");
                
                employees emp = new employees(ID,name, surname,nationalID, gender, dob,mobile,email,address,dept,grade,salary,accountNo);
                employeeList.add(emp);
//              

            }
            return employeeList;
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }
    
    
    public static employees getEmployeeByEmployeeID(String query) {

        try {
            String sql = "SELECT * FROM tblemployees WHERE employeeId='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String ID = resultSet.getString("employeeID");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String nationalID = resultSet.getString("nationalID");
                String gender = resultSet.getString("gender");
                String dob = resultSet.getString("dob");
                String mobile = resultSet.getString("phoneNumber");
                String email = resultSet.getString("email");
                String address = resultSet.getString("homeAddress");
                String dept = resultSet.getString("department");
                String grade = resultSet.getString("grade");
                int salary = resultSet.getInt("salary");
                int accountNo = resultSet.getInt("accountNo");
                
                employees account = new employees();
                account.setID(ID);
                account.setName(name);
                account.setSurname(surname);
                account.setNationalID(nationalID);
                account.setGender(gender);
                account.setDob(dob);
                account.setMobile(mobile);
                account.setEmail(email);
                account.setAddress(address);
                account.setDepartment(dept);
                account.setGrade(grade);
                account.setSalary(salary);
                account.setAccountNo(accountNo);
                System.out.println(account);
                return account;

            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }
    
    public static employees getEmployeeByNationalID(String query) {

        try {
            String sql = "SELECT * FROM tblemployees WHERE nationalID='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String ID = resultSet.getString("employeeID");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String nationalID = resultSet.getString("nationalID");
                String gender = resultSet.getString("gender");
                String dob = resultSet.getString("dob");
                String mobile = resultSet.getString("phoneNumber");
                String email = resultSet.getString("email");
                String address = resultSet.getString("homeAddress");
                String dept = resultSet.getString("department");
                String grade = resultSet.getString("grade");
                int salary = resultSet.getInt("salary");
                int accountNo = resultSet.getInt("accountNo");
                
                employees account = new employees();
                account.setID(ID);
                account.setName(name);
                account.setSurname(surname);
                account.setNationalID(nationalID);
                account.setGender(gender);
                account.setDob(dob);
                account.setMobile(mobile);
                account.setEmail(email);
                account.setAddress(address);
                account.setDepartment(dept);
                account.setGrade(grade);
                account.setSalary(salary);
                account.setAccountNo(accountNo);
                System.out.println(account);
                return account;

            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }
    public static boolean confirmpass(saveEmployee Saveemployee){
        if (Saveemployee.getConfirmPassword().equals(Saveemployee.getPassword())){
            return true;
        }
        else{
            return false;
        }
    }
    
    public static String getEmpID(String nationalID){
        employees acc = getEmployeeByNationalID(nationalID);
        if(acc != null){
            return acc.ID;
        }
        return acc.ID;
    
    }
    public static boolean checkDuplicateEmployee(String nationalID) {
        
        employees account= getEmployeeByNationalID(nationalID);
        if(account!=null){
            return true;
            }
        return false;
     }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getNationalID() {
        return nationalID;
    }

    public void setNationalID(String nationalID) {
        this.nationalID = nationalID;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   
    
    @Override
    public String toString() {
        return "employees{" + "name=" + name + ", surname=" + surname + ", nationalID=" + nationalID + ", gender=" + gender + ", dob=" + dob + ", address=" + address + ", email=" + email + ", mobile=" + mobile + ", department=" + department + ", grade=" + grade + ", salary=" + salary + ", accountNo=" + accountNo + ", username=" + username + ", password=" + password + '}';
    }
    
    
            
    
    
    
}
