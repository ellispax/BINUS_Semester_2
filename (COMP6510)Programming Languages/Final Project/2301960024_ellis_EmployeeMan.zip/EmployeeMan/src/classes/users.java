package classes;

/**
 *
 * @author Computer
 */

import static dbconn.DBconnection.connecto;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import javax.activity.InvalidActivityException;
import javax.swing.JOptionPane;

public class users implements Serializable{
    private
            String userID;
            String employeeid;
            String username;
            String password;
            String admin;
            boolean isAdmin;
     
    public users(){}
    
    
    public users(String userID,String employeeid, String username, String password,String admin,boolean isAdmin){
        this.userID = userID;
        this.employeeid = employeeid;
        this.username = username;
        this.password = password;
        this.admin = admin;
        this.isAdmin = isAdmin;
        
        
    }
    
    
    
    public static List<users> getAllUsers() {

        try {
            String sql = "SELECT * FROM  tblusers";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
             List<users> userAccountsList = new ArrayList<users>();
            while (resultSet.next()) {
                String id = resultSet.getString("usrId");
                String employeeid = resultSet.getString("employeeId");
                String username = resultSet.getString("username");               
                String password = resultSet.getString("password");
                String admin = resultSet.getString("access");
                boolean isAdmin = resultSet.getBoolean("isAdmin");
                users account = new users();
                
                account.setUserID(id);
                account.setEmployeeid(employeeid);
                account.setUsername(username);               
                account.setPassword(password); 
                account.setAdmin(admin);
                account.setIsAdmin(isAdmin);
                
               userAccountsList.add(account);
            }
            return userAccountsList;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static users getUserByUserName(String query) {

        try {
            String sql = "SELECT * FROM tblusers WHERE username ='"+query+"'" ;
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String id = resultSet.getString("usrId");
                String employeeId  = resultSet.getString("employeeId");
                String username = resultSet.getString("username");               
                String password = resultSet.getString("password");
                String admin  = resultSet.getString("access");
                boolean isAdmin = resultSet.getBoolean("isAdmin");
                
                users account = new users();
                account.setUserID(id);
                account.setEmployeeid(employeeId);
                account.setUsername(username);                
                account.setPassword(password);
                account.setAdmin(admin);
                account.setIsAdmin(isAdmin);
                System.out.println(account.username + " " + account.employeeid+ " " + account.password + " " + account.admin);
                return account;

            }
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
     
    }
    
    
    
    public String getUserID(){
        return userID;
    }
    public String getUsername(){
        return username;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }
    
    public String getPassword(){
        return password;
    }

    public String getAdmin() {
        return admin;
    }

    public boolean isIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }
    

    public void setAdmin(String admin) {
        this.admin = admin;
    }
    
        
    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "users{" + "userID=" + userID + ", username=" + username + ", password=" + password + '}';
    }
    
    
}
