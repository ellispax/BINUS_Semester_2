/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
import static dbconn.DBconnection.connecto;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import static dbconn.DBconnection.currentUser;

/**
 *
 * @author Computer
 */
public class leaveRequests {
    private
            int ID;
            String employeeid;
            Date sdate;
            Date edate;
            String reason;
            boolean approved;
            
    public leaveRequests(){}
            
    public leaveRequests(String employeeid, Date sdate, Date edate, String reason, Boolean approved){
        this.employeeid = employeeid;
        this.sdate  = sdate;
        this.edate = edate;
        this.reason = reason;
        this.approved = approved;               
    
    }
    
    public leaveRequests(int ID, Date sdate, Date edate, String reason, Boolean approved){
        this.ID = ID;
        this.sdate  = sdate;
        this.edate = edate;
        this.reason = reason;
        this.approved = approved;               
    
    }
    
    public leaveRequests(int ID, String employeeid, Date sdate, Date edate, String reason, Boolean approved){
        this.ID = ID;
        this.employeeid = employeeid;
        this.sdate = sdate;
        this.edate = edate;
        this.reason = reason;
        this.approved = approved;
                          
    }
    
    public static leaveRequests createLeaveRequest(String employeeid,Date sdate, Date edate,String reason,boolean approved ){
        leaveRequests LeaveRequests = new leaveRequests(employeeid, sdate,edate,reason,approved);
        saveLeaveRequests(LeaveRequests);
        return LeaveRequests;
        
    }
    
    public static boolean saveLeaveRequests(leaveRequests LeaveRequests) {

        try {
            String sql = "INSERT INTO tblleave(employeeId,sdate,edate,reason) VALUES(?,?,?,?)";
            PreparedStatement pstmt = connecto.prepareStatement(sql);
            //pstmt.setInt(1, new Random().nextInt(10000));
            pstmt.setString(1, LeaveRequests.getEmployeeid());
            java.util.Date sdate = LeaveRequests.getSdate();
            java.sql.Date sqlDate1 = new java.sql.Date(sdate.getTime());
            pstmt.setDate(2, sqlDate1);
            java.util.Date edate = LeaveRequests.getSdate();
            java.sql.Date sqlDate2 = new java.sql.Date(edate.getTime());
            pstmt.setDate(3, sqlDate2);
            pstmt.setString(4 , LeaveRequests.getReason());
           
            int i = pstmt.executeUpdate();
            if (i == 1) {
                return true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static List<leaveRequests> getAllRequests()  {

        try {
            String sql = "SELECT * FROM  tblleave";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<leaveRequests> leaveRequestsList = new ArrayList<leaveRequests>();
             
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                String empid = resultSet.getString("employeeId");
                Date startDate = resultSet.getDate("sdate");
                Date endDate = resultSet.getDate("edate");
                String reason = resultSet.getString("reason");
                //DateFormat format = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
                Boolean approved = resultSet.getBoolean("approved");
                
                leaveRequests Requests = new leaveRequests(id,empid, startDate, endDate, reason, approved);
                leaveRequestsList.add(Requests);
            }
            return leaveRequestsList;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static List<leaveRequests> getLeaveRequestsByEmployeeid(String query) {

        try {
            String sql = "SELECT * FROM tblleave WHERE employeeId='" + query + "'";
            PreparedStatement preparedStatement = connecto.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<leaveRequests> leaveRequestsList = new ArrayList<leaveRequests>();
            while (resultSet.next()) {
                Integer id = resultSet.getInt("ID");
                Date startDate = resultSet.getDate("sdate");
                Date endDate = resultSet.getDate("edate");
                String reason = resultSet.getString("reason");
                Boolean approved = resultSet.getBoolean("approved");
                leaveRequests Requests = new leaveRequests(id, startDate, endDate, reason,approved);
                leaveRequestsList.add(Requests);

            }
            return leaveRequestsList;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public Date getSdate() {
        return sdate;
    }

    public void setSdate(Date sdate) {
        this.sdate = sdate;
    }

    public Date getEdate() {
        return edate;
    }

    public void setEdate(Date edate) {
        this.edate = edate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean getApproved() {
        return approved;
    }

    public  void setApproved(boolean approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return "leaveRequests{" + "ID=" + ID + ", employeeid=" + employeeid + ", sdate=" + sdate + ", edate=" + edate + ", reason=" + reason + '}';
    }
    
    
    
}
