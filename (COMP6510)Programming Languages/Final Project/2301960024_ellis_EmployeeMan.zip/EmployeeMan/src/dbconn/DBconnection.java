/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbconn;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Computer
 */
public class DBconnection {
    public static Connection connecto= null;
        public static String currentUser= null;
    
    public DBconnection(){}
    
    public static Connection getConn(){
        
            String url = "jdbc:mysql://localhost/javaprojdb";
//            String url = "jdbc:http://localhost:3306/mysql/";
            String username = "root";
            String password = "";

            System.out.println("Connecting database...");

            try  {
                connecto = DriverManager.getConnection(url, username, password);
                System.out.println("Database connected!");
                return connecto;
                
            } catch (SQLException e) {
                throw new IllegalStateException("Cannot connect the database!", e);
            }
            
    }
    
}
//    public static Connection getConn()
//    {
//         try {   
//          // Class.forName("org.apache.derby.jdbc.ClientDriver");
//            connecto = DriverManager.getConnection ("jdbc:mysql://localhost:7777/javapojdb","root","");
//            System.out.println("Database connected");
//            return connecto;
//        } catch (Exception e) {
//            return null;
//        }
//
//    }
//}
