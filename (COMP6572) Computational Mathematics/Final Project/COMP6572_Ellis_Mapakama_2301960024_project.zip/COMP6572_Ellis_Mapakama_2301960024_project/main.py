import csv
import numpy as np 
import matplotlib.pyplot as plt 
import pandas as pd 
import scipy as sc 
import math
import getpass
import os

#------ Interpolation Functions 
def gauss_elm(a,b):
  n = len(b)
  # Elimination Phase
  for k in range(0,n-1):
      for i in range(k+1,n):
         if a[i][k] != 0.0:
             lam = a[i][k]/a[k][k]
             for j in range(k+1,n):
                  a[i][j] = a[i][j] - lam*a[k][j]
             b[i] = b[i] - lam*b[k]
  
  # Back substitution
  for k in range(n-1,-1,-1):
      b[k] = (b[k] - np.dot(a[k][k+1:n],b[k+1:n]))/a[k][k]
  return b

def direct(x,y,xp,n):
  b = [[None for row in range(n+1)] for col in range(n+1)]
  c = [None for row in range(n+1)]

  for i in range(0,n+1):
    c[i] = y[i]
    for j in range(0,n+1):
      b[i][j] = x[i]**j
  
  # Solve the system of linear equation using gauss elimination, a0,a1,...,an
  a = gauss_elm(b,c)
    
  # Estimate y for x = xp using polynomial a0 + a1.xp + a2.xp^2 + ... + an.x^n
  yp = 0
  for i in range(0,n+1):
    yp = yp + a[i]*xp**i
  return yp

# Calculate (f(xa)-f(xb)) / ((xa-xb))
def dy_dx(xa,xb,ya,yb):
  return (ya-yb)/(xa-xb)

def newton(x,y,xp,n):
  b = [[None for row in range(n+1)] for col in range(n+1)]
  b[0][0] = y[0]
  
  for i in range(0,n+1):
    for j in range(0,n+1-i):
      if(i==0): 
        b[i][j] = y[j]
      else:
        b[i][j] = dy_dx(x[j+i],x[j],b[i-1][j+1],b[i-1][j])
  
  # Estimate y at xp using polynomial 
  # b0 +  b1.(xp-x0) + b2.(xp-x0)(xp-x1) + ... + bn.(xp-x0)(xp-x1)...(xp-xn-1)
  #             m                m                               m
  yp = b[0][0]
  #print(yp)
  for i in range(1,n+1):
    m = 1
    for j in range(0,i):
      m = m*(xp-x[j])
    yp = yp + b[i][0]*m
   # print(b[i][0])
  return yp

def lagrange(x,y,xp,n):
  # Calculate l[i]
  l = []
  for i in range(0,n+1):
    m = 1
    for j in range(0,n+1):
      if(j!=i): 
        m = m * (xp-x[j])/(x[i]-x[j])
    l.append(m)

  # Estimate yp at xp using polynomial
  # l[0].y[0] + l[1].y[1] + ... + l[n].y[n]
  yp = 0
  for i in range(0,n+1):
    yp = yp + l[i]*y[i]
  return yp

#-----------------------------


#making the dataframe
df = pd.read_csv('csv/df.csv',usecols = [0,1,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20])


new_df = df[['Country Name','Country Code','1960','1961','1962','1963','1964','1965','1966','1967','1968','1969']]
df_3 = new_df.loc[df['Country Name'] == 'Angola']
dff = df_3[['1960','1961','1962','1963','1964','1965','1966','1967','1968','1969']]



x = list(dff.columns.values.tolist())# getting the x-list values (years)
ylist = dff.values.tolist()
for n in ylist:
	y = n


dff2 = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] #without 1964

dff_2 = dff2[['1963','1965']] #1st order

dff_3 = dff2[['1962','1963','1965']] #2nd order

dff_4 = dff2[['1963','1965','1966','1967']] #3rd order

x2 = list(dff_2.columns.values.tolist())
test_list = list(map(int, x2))
y2list = dff_2.values.tolist()
for a in y2list:
	y2 = a


x3 = list(dff_3.columns.values.tolist())
x3list = list(map(int, x3))
y3list = dff_3.values.tolist()
for b in y3list:
	y3 = b


x4 = list(dff_4.columns.values.tolist())
x4list = list(map(int,x4))
y4list = dff_4.values.tolist()
for c in y4list:
	y4 = c

value = direct(test_list,y2,1964,1)
value2 = newton(test_list,y2,1964,1)
value3 = lagrange(test_list,y2,1964,1)

value4 = direct(x3list,y3,1964,2)
value5 = newton(x3list,y3,1964,2)
value6 = lagrange(x3list,y3,1964,2)

value7 = direct(x4list,y4,1964,3)
value8 = newton(x4list,y4,1964,3)
value9 = lagrange(x4list,y4,1964,3)

truValue = 57350440

def visual():
	#First order Interpolation Calculations
	

	print("First Order (Linear) Interpolation")
	print("-------------------------------------------------------")
	print("Direct Interpolation: ", value," with true error value of: ",truValue - value)
	print("\nNewton Interpolation: ", value2," with true error value of: ",truValue - value2)
	print("\nLagrange Interpolation: ", value3," with true error value of: ",truValue - value3)
	print("\nThe True Value for 1964:", truValue)
	print("=======================================================")

	#Second Order Interpolation Calculations
	
	print("Second Order (Quadratic) Interpolation Solutions ")
	print("-------------------------------------------------------")
	print('\nDirect Interpolation :', value4, " with true error value of: ",truValue - value4)
	print('\nNewton Raphson Interpolation: ', value5, " with true error value of: ",truValue - value5)
	print('\nLagrange Interpolation: ', value6, " with true error value of: ",truValue - value6)
	print("\nThe True Value for 1964:", truValue,)
	print("=======================================================")
	#Third Order Interpolation CAlculations
	

	print("Third Order (Cubic) Interpolation Solutions ")
	print("-------------------------------------------------------")
	print('Direct Interpolation: ', value7, " with true error value of: ",(truValue-value7))

	print('\nNewton Raphson Interpolation: ', value8," with true error value of: ",truValue - value8)
	print('\nLagrange Interpolation: ', value9," with true error value of: ",truValue - value9)
	print("\nThe True Value for 1964:", truValue)
	print("=======================================================")

def getDirect1st():
	df_Direct = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Direct.insert(4,'1964',value2)

	x_direct = list(df_Direct.columns.values.tolist())
	y_direct = df_Direct.values.tolist()
	for c in y_direct:
		yDirect = c
	return x_direct, yDirect

def getDirect2nd():
	df_Direct = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Direct.insert(4,'1964',value4)

	x_direct = list(df_Direct.columns.values.tolist())
	y_direct = df_Direct.values.tolist()
	for c in y_direct:
		yDirect = c
	return x_direct, yDirect

def getDirect3rd():
	df_Direct = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Direct.insert(4,'1964',value7)

	x_direct = list(df_Direct.columns.values.tolist())
	y_direct = df_Direct.values.tolist()
	for c in y_direct:
		yDirect = c
	return x_direct, yDirect


def getNewton1st():
	df_Newton = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Newton.insert(4,'1964',value2)

	x_newton = list(df_Newton.columns.values.tolist())
	y_newton = df_Newton.values.tolist()
	for c in y_newton:
		yNewton = c
	return x_newton, yNewton

def getNewton2nd():
	df_Newton = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Newton.insert(4,'1964',value5)

	x_newton = list(df_Newton.columns.values.tolist())
	y_newton = df_Newton.values.tolist()
	for c in y_newton:
		yNewton = c
	return x_newton, yNewton

def getNewton3rd():
	df_Newton = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']] 
	df_Newton.insert(4,'1964',value8)

	x_newton = list(df_Newton.columns.values.tolist())
	y_newton = df_Newton.values.tolist()
	for c in y_newton:
		yNewton = c
	return x_newton, yNewton

def getLagrange1st():
	df_Lagrange = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']]
	df_Lagrange.insert(4,'1964',value3)

	x_lagrange = list(df_Lagrange.columns.values.tolist())
	y_lagrange = df_Lagrange.values.tolist()
	for n in y_lagrange:
		yLagrange = n
	return x_lagrange, yLagrange

def getLagrange2nd():
	df_Lagrange = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']]
	df_Lagrange.insert(4,'1964',value6)

	x_lagrange = list(df_Lagrange.columns.values.tolist())
	y_lagrange = df_Lagrange.values.tolist()
	for n in y_lagrange:
		yLagrange = n
	return x_lagrange, yLagrange

def getLagrange3rd():
	df_Lagrange = df_3[['1960','1961','1962','1963','1965','1966','1967','1968','1969']]
	df_Lagrange.insert(4,'1964',value9)

	x_lagrange = list(df_Lagrange.columns.values.tolist())
	y_lagrange = df_Lagrange.values.tolist()
	for n in y_lagrange:
		yLagrange = n
	return x_lagrange, yLagrange


#making graph lists for 1st order
xDirect, yDirect = getDirect1st()
xNewton,yNewton = getNewton1st()
xLagrange, yLagrange = getLagrange1st()

#making graph lists for 2nd Order
x2Direct, y2Direct = getDirect2nd()
x2Newton, y2Newton = getNewton2nd()
x2Lagrange, y2Lagrange = getLagrange2nd()

#making graph lists for 3rd order
x3Direct, y3Direct = getDirect3rd()
x3Newton, y3Newton = getNewton3rd()
x3Lagrange, y3Lagrange = getLagrange3rd()

def plot2nd():
	fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
	fig.suptitle('Quadratic (2nd Order) Interpolation for the Year 1964')
	ax1.plot(x, y,'*')
	ax1.plot(x2Direct, y2Direct, '*')
	ax1.set_title('Direct Interpolation')
	ax2.plot(x,y, '*')
	ax2.plot(x2Newton,y2Newton, '*')
	ax2.set_title('Newton Raphson Interpolation')
	ax3.plot(x,y,'*')
	ax3.plot(x2Lagrange, y2Lagrange,'*')
	ax3.set_title('Lagrange Interpolation')
	ax4.plot(x,y, '*')
	ax4.set_title('True Data Plot')

	for ax in fig.get_axes():
	    ax.label_outer()

	plt.show()


def plot1st():	
	fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
	fig.suptitle('Linear (1st Order) Interpolation for the Year 1964')
	ax1.plot(x, y, '*')
	ax1.plot(xDirect, yDirect, '*')
	ax1.set_title('Direct Interpolation')
	ax2.plot(x,y, '*')
	ax2.plot(xNewton,yNewton, '*')
	ax2.set_title('Newton Raphson Interpolation')
	ax3.plot(x,y, '*')
	ax3.plot(xLagrange, yLagrange, '*')
	ax3.set_title('Lagrange Interpolation')
	ax4.plot(x,y, '*')
	ax4.set_title('True Data Plot')

	for ax in fig.get_axes():
	    ax.label_outer()

	plt.show()

def plot3rd():
	fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
	fig.suptitle('Cubic (3rd Order) Interpolation  for the year 1964')
	ax1.plot(x, y, '*')
	ax1.plot(x3Direct, y3Direct, '*')
	ax1.set_title('Direct Interpolation')
	ax2.plot(x,y, '*')
	ax2.plot(x3Newton,y3Newton, '*')
	ax2.set_title('Newton Raphson Interpolation')
	ax3.plot(x,y, '*')
	ax3.plot(x3Lagrange, y3Lagrange, '*')
	ax3.set_title('Lagrange Interpolation')
	ax4.plot(x,y, '*')
	ax4.set_title('True Data Plot')

	for ax in fig.get_axes():
	    ax.label_outer()

	plt.show()


def showData():
	print("The Following Popullation Data is Used in this Program to Demonstrate Interpolation")
	print("-------------------------------------------------------------------------------------")
	print(df_3)
	print("-------------------------------------------------------------------------------------")
	print("The value for the year 1964 is removed and interpolation will be used to get an estimate.")
	print("-------------------------------------------------------------------------------------")
	print(dff2)
	print("-------------------------------------------------------------------------------------")




def login():
	print("""\n
                    *******************************************
                        Welcome To Interpolation Illustration
                    *******************************************
                        Please use your credentials to login
                    -------------------------------------------""")

	status = False
	while status ==False:
		username = input("USERNAME >> _ _ ")
		password  = getpass.getpass()
		if username == "ellis" and password == "pax":
			print("welcome user >> ", username)
			os.system('cls')
			menu()
			status = True
			
		else:
			print("Invalid Login Credentials !!\nIf you dont have login credentials contact system adminstrator.")



def graphs():
	print("""\n
				*********************************
					GRAPHS
				*********************************
				[1] LINEAR (1st ORDER) INTERPOLATION
				[2] QUADRATIC (2nd ORDER) IMTERPOLATION
				[3] CUBIC (3rd ORDER) INTERPOLATION 
				[R] RETURN
				---------------------------------
			""")

def show():
	print("""\n
				*********************************
					MAIN MENU
				*********************************
					[1] CHECK DATA
					[2] COMPUTE INTERPOLATES
					[3] CHECK GRAPHS 
					[Q] QUIT
				---------------------------------
			""")

def menu():
	show()
	state = False
	while state == False:
		resp = input("Option:> ")

		if resp == '1':
			showData()
			input("Press Enter To Continue..")
			os.system('cls')
			show()
		elif resp == '2':
			visual()
			input("Press Enter to Continue..")
			os.system('cls')
			show()
		elif resp == '3':
			graphs()
			loop = False
			while loop == False:
				inpt = input("choice >: ")
				if inpt == "1":
					plot1st()
					os.system('cls')
					graphs()
				elif inpt == "2":
					plot2nd()
					os.system('cls')
					graphs()
				elif inpt == "3":
					plot3rd()
					os.system('cls')
					graphs()
				elif inpt.upper() == "R":
					loop = True
					os.system('cls')
					show()

		elif resp.upper() == 'Q':
			print("Thank You For Using This Program To Demonstrate About Interpolation...")
			exit()


def run():
	login()

run()